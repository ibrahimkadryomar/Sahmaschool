// عرض الواجبات بناءً على اختيار المستخدم
function showAssignments() {
    const studentName = document.getElementById("student-name").value;
    const stage = document.getElementById("stage").value;
    const grade = document.getElementById("grade").value;
    const classSection = document.getElementById("class").value;
    const assignmentsDiv = document.getElementById("assignments");

    if (!studentName) {
        alert("يرجى اختيار اسم الطالب");
        return;
    }

    // قائمة الواجبات المخصصة
    const assignments = {
        "ابراهيم الغصلان": [
            { subject: "الرياضيات", lesson: "الجمع والطرح", page: "ص 12" },
            { subject: "العلوم", lesson: "المادة وخواصها", page: "ص 20" }
        ],
        "خالد الجميل": [
            { subject: "اللغة العربية", lesson: "الفاعل والمفعول", page: "ص 15" },
            { subject: "اللغة الإنجليزية", lesson: "Lesson 3 - Grammar", page: "ص 25" }
        ],
        "بندر العتيبي": [
            { subject: "الفيزياء", lesson: "قوانين نيوتن", page: "ص 30" },
            { subject: "الكيمياء", lesson: "التفاعلات الكيميائية", page: "ص 45" }
        ]
    };

    // استخراج الواجبات الخاصة بالطالب
    const studentAssignments = assignments[studentName] || [];
    assignmentsDiv.innerHTML = `<h3>واجبات ${studentName} في ${stage} ${grade} - فصل ${classSection}:</h3>`;
    
    if (studentAssignments.length > 0) {
        studentAssignments.forEach(task => {
            assignmentsDiv.innerHTML += `
                <p class="assignment-item">
                    <strong>المادة:</strong> ${task.subject} | 
                    <strong>الدرس:</strong> ${task.lesson} | 
                    <strong>الصفحة:</strong> ${task.page}
                </p>`;
        });
    } else {
        assignmentsDiv.innerHTML += `<p class="assignment-item">لا توجد واجبات لهذا الطالب.</p>`;
    }
}
